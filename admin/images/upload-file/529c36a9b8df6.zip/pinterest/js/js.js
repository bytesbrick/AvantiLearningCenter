jQuery(document).ready(function($) {
	
	$('#container').masonry({
		  itemSelector: '.pin',
		  isFitWidth: true
	});



});
